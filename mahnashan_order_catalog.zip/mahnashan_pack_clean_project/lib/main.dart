import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

const ink = Color(0xFF171411);
const gold = Color(0xFFD6AD62);
const boxCategory = 'جعبه‌ها';
const trayCategory = 'سینی‌ها';
const drinkCategory = 'آبمیوه و بستنی';
const categories = [boxCategory, trayCategory, drinkCategory];
const whatsappNumber = '989388462634';
const productKey = 'mahnashan_products_v2';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = ProductStore();
  await store.load();
  runApp(MahnashanApp(store: store));
}

class Product {
  Product({required this.name, required this.category, this.size = '', this.description = ''});
  final String name, category, size, description;
  Map<String, dynamic> toJson() => {
    'name': name, 'category': category, 'size': size, 'description': description,
  };
  factory Product.fromJson(Map<String, dynamic> json) => Product(
    name: json['name'] as String? ?? '',
    category: json['category'] as String? ?? boxCategory,
    size: json['size'] as String? ?? '',
    description: json['description'] as String? ?? '',
  );
}

class ProductStore extends ChangeNotifier {
  final List<Product> products = [];
  final Map<String, int> cart = {};

  List<Product> get defaults => [
    for (final name in [
      'جعبه تک پرس با سرویس', 'جعبه ارکیده', 'جعبه گلتاج', 'جعبه خوشه',
      'جعبه زرین', 'جعبه زیبا', 'جعبه شیرین', 'جعبه ۱۲ پرسی', 'جعبه ساندویچ',
    ]) Product(name: name, category: boxCategory),
    for (final name in [
      'سینی تک پرسی', 'سینی تک پرس با سرویس', 'سینی دو پرس با سرویس',
      'سینی سه پرس ارتفاع ۵', 'سینی سه پرس ارتفاع ۴', 'سینی شیرین', 'سینی نیم پرسی',
    ]) Product(name: name, category: trayCategory),
    for (final name in [
      'جا لیوانی دو عددی', 'جا لیوانی ۴ عددی', 'سینی بستنی ۲ عددی',
      'سینی بستنی ۴ عددی', 'سینی هرمی', 'جا لیوانی دسته‌دار',
    ]) Product(name: name, category: drinkCategory),
  ];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(productKey);
    if (raw != null) {
      try {
        products.addAll((jsonDecode(raw) as List).map(
          (e) => Product.fromJson(e as Map<String, dynamic>),
        ));
      } catch (_) { products.clear(); }
    }
    // Replace the earlier demonstration-only catalog with the requested real product list.
    if (products.isEmpty || products.every((p) =>
        ['ظرف بیرون‌بر', 'لیوان نوشیدنی', 'ظرف بستنی'].contains(p.name))) {
      products
        ..clear()
        ..addAll(defaults);
      await _save();
    }
  }

  Future<void> add(Product p) async { products.add(p); await _save(); notifyListeners(); }
  Future<void> update(int i, Product p) async { products[i] = p; await _save(); notifyListeners(); }
  Future<void> remove(int i) async { products.removeAt(i); await _save(); notifyListeners(); }
  void addToCart(Product p, int count) {
    if (count < 1) return;
    cart[p.name] = (cart[p.name] ?? 0) + count;
    notifyListeners();
  }
  void setCartCount(String name, int count) {
    if (count <= 0) { cart.remove(name); } else { cart[name] = count; }
    notifyListeners();
  }
  void clearCart() { cart.clear(); notifyListeners(); }
  int get cartCount => cart.values.fold(0, (a, b) => a + b);

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(productKey, jsonEncode(products.map((p) => p.toJson()).toList()));
  }
}

class MahnashanApp extends StatelessWidget {
  const MahnashanApp({super.key, required this.store});
  final ProductStore store;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ماهنشان پک',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: gold),
      scaffoldBackgroundColor: const Color(0xFFF5F1E8),
      appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: Colors.white, elevation: 0),
      cardTheme: CardThemeData(
        color: Colors.white, elevation: 5, shadowColor: const Color(0x33251B0C),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        margin: const EdgeInsets.only(bottom: 13),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
      ),
    ),
    home: HomePage(store: store),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.store});
  final ProductStore store;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String filter = categories.first;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: widget.store,
    builder: (context, _) => Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.inventory_2_rounded, color: gold),
          SizedBox(width: 9),
          Text('ماهنشان پک', style: TextStyle(fontWeight: FontWeight.w900)),
        ]),
        actions: [
          IconButton(
            tooltip: 'سبد سفارش',
            onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => CartPage(store: widget.store))),
            icon: Stack(clipBehavior: Clip.none, children: [
              const Icon(Icons.shopping_bag_rounded),
              if (widget.store.cartCount > 0)
                Positioned(right: -7, top: -7, child: CircleAvatar(
                  radius: 9, backgroundColor: gold,
                  child: Text('${widget.store.cartCount}', style: const TextStyle(fontSize: 10, color: ink)),
                )),
            ]),
          ),
          IconButton(
            tooltip: 'پنل مدیریت',
            onPressed: _adminLogin,
            icon: const Icon(Icons.admin_panel_settings_rounded),
          ),
        ],
      ),
      body: IndexedStack(index: tab, children: [_home(), _catalog(), _about()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'محصولات'),
          NavigationDestination(icon: Icon(Icons.business_rounded), label: 'درباره ما'),
        ],
      ),
    ),
  );

  Widget _home() => ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 28), children: [
    Container(
      padding: const EdgeInsets.fromLTRB(22, 25, 22, 23),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF100F0D), Color(0xFF45331E), Color(0xFF171411)]),
        border: Border.all(color: gold.withOpacity(.75)),
        boxShadow: const [BoxShadow(color: Color(0x553A2B16), blurRadius: 22, offset: Offset(0, 10))],
      ),
      child: Column(children: [
        Container(
          width: 92, height: 92,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: [Color(0xFFFFE9B9), Color(0xFFB98232)]),
            boxShadow: const [BoxShadow(color: Color(0x88D6AD62), blurRadius: 22)],
            border: Border.all(color: Colors.white, width: 2),
          ),
          child: const Icon(Icons.inventory_2_rounded, color: ink, size: 48),
        ),
        const SizedBox(height: 15),
        const Text('ماهنشان پک', style: TextStyle(color: gold, fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        const Text('چاپ و بسته‌بندی', style: TextStyle(color: Colors.white70, fontSize: 15)),
        const SizedBox(height: 12),
        const Text('بسته‌بندی حرفه‌ای برای کسب‌وکار شما',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
      ]),
    ),
    const SizedBox(height: 25),
    const Text('دسته‌بندی محصولات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: ink)),
    const SizedBox(height: 12),
    _categoryTile(boxCategory, Icons.inventory_2_rounded, const Color(0xFFB77A35), '۹ مدل جعبه بسته‌بندی'),
    _categoryTile(trayCategory, Icons.dashboard_customize_rounded, const Color(0xFF4D9290), '۷ مدل سینی'),
    _categoryTile(drinkCategory, Icons.local_drink_rounded, const Color(0xFFB56D91), '۶ مدل جا لیوانی و بستنی'),
    const SizedBox(height: 10),
    const Text('برای مشاهده و انتخاب، روی هر محصول بزنید', textAlign: TextAlign.center,
      style: TextStyle(color: Colors.black54)),
  ]);

  Widget _categoryTile(String title, IconData icon, Color accent, String subtitle) => Card(
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: () => setState(() { filter = title; tab = 1; }),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          _raisedIcon(icon, accent, size: 62),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17, color: ink)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
          ])),
          const Icon(Icons.arrow_back_ios_new_rounded, size: 17, color: gold),
        ]),
      ),
    ),
  );

  Widget _catalog() {
    final list = widget.store.products.where((p) => filter == 'همه' || p.category == filter).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('کاتالوگ محصولات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: ink)),
      const SizedBox(height: 12),
      Wrap(spacing: 8, runSpacing: 8, children: categories.map((c) => ChoiceChip(
        label: Text(c), selected: filter == c,
        selectedColor: gold.withOpacity(.35),
        onSelected: (_) => setState(() => filter = c),
      )).toList()),
      const SizedBox(height: 16),
      ...list.map((p) => ProductCard(product: p, onTap: () => _openProduct(p))),
    ]);
  }

  void _openProduct(Product product) => Navigator.push(context, MaterialPageRoute(
    builder: (_) => ProductDetailPage(store: widget.store, product: product)));

  Widget _about() => ListView(padding: const EdgeInsets.all(22), children: const [
    SizedBox(height: 20),
    Icon(Icons.business_rounded, size: 72, color: gold),
    SizedBox(height: 16),
    Text('ماهنشان پک', textAlign: TextAlign.center,
      style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: ink)),
    SizedBox(height: 8),
    Text('چاپ و بسته‌بندی', textAlign: TextAlign.center),
    SizedBox(height: 18),
    Text('برای انتخاب محصولات و ثبت سفارش، از کاتالوگ استفاده کنید.',
      textAlign: TextAlign.center),
  ]);

  Future<void> _adminLogin() async {
    final pin = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('ورود به پنل مدیریت'),
      content: TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'رمز مدیریت', hintText: 'رمز آزمایشی: 1234')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
        FilledButton(onPressed: () => Navigator.pop(ctx, pin.text == '1234'), child: const Text('ورود')),
      ],
    ));
    pin.dispose();
    if (!mounted || ok != true) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(store: widget.store)));
  }
}

Widget _raisedIcon(IconData icon, Color accent, {double size = 64}) => Container(
  width: size, height: size,
  decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(size * .30),
    gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color.lerp(accent, Colors.white, .28)!, accent, Color.lerp(accent, Colors.black, .12)!]),
    boxShadow: [BoxShadow(color: accent.withOpacity(.34), blurRadius: 13, offset: const Offset(0, 6))],
    border: Border.all(color: Colors.white.withOpacity(.9), width: 1.5),
  ),
  child: Icon(icon, size: size * .53, color: Colors.white,
    shadows: const [Shadow(color: Colors.black45, blurRadius: 5, offset: Offset(1, 2))]),
);

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product, required this.onTap});
  final Product product;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final isBox = product.category == boxCategory;
    final isTray = product.category == trayCategory;
    final icon = isBox ? Icons.inventory_2_rounded :
      isTray ? Icons.dashboard_customize_rounded :
      (product.name.contains('لیوان') ? Icons.local_cafe_rounded : Icons.icecream_rounded);
    final color = isBox ? const Color(0xFFB77A35) :
      isTray ? const Color(0xFF4D9290) : const Color(0xFFB56D91);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            _raisedIcon(icon, color, size: 66),
            const SizedBox(width: 13),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(product.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: ink)),
              const SizedBox(height: 5),
              Text(product.category, style: const TextStyle(color: Colors.black54, fontSize: 12)),
              const SizedBox(height: 5),
              const Text('برای انتخاب تعداد لمس کنید', style: TextStyle(color: Color(0xFF9A753B), fontSize: 11)),
            ])),
            const Icon(Icons.add_circle_rounded, color: gold, size: 27),
          ]),
        ),
      ),
    );
  }
}

class ProductDetailPage extends StatefulWidget {
  const ProductDetailPage({super.key, required this.store, required this.product});
  final ProductStore store;
  final Product product;
  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  int quantity = 1;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('جزئیات محصول')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const SizedBox(height: 22),
        _raisedIcon(
          widget.product.category == boxCategory ? Icons.inventory_2_rounded :
          widget.product.category == trayCategory ? Icons.dashboard_customize_rounded :
          (widget.product.name.contains('لیوان') ? Icons.local_cafe_rounded : Icons.icecream_rounded),
          gold, size: 132),
        const SizedBox(height: 24),
        Text(widget.product.name, textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)),
        const SizedBox(height: 8),
        Text(widget.product.category, style: const TextStyle(color: Colors.black54)),
        const Spacer(),
        const Text('تعداد موردنظر را انتخاب کنید', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton.filledTonal(onPressed: quantity > 1 ? () => setState(() => quantity--) : null,
            icon: const Icon(Icons.remove_rounded)),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Text('$quantity', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
          IconButton.filled(onPressed: () => setState(() => quantity++),
            icon: const Icon(Icons.add_rounded)),
        ]),
        const SizedBox(height: 22),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: ink, foregroundColor: gold,
            padding: const EdgeInsets.symmetric(vertical: 16)),
          onPressed: () {
            widget.store.addToCart(widget.product, quantity);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('محصول به سبد سفارش اضافه شد')));
            Navigator.pop(context);
          },
          icon: const Icon(Icons.shopping_bag_rounded),
          label: const Text('افزودن به سبد سفارش'),
        )),
        const SizedBox(height: 12),
      ]),
    ),
  );
}

class CartPage extends StatelessWidget {
  const CartPage({super.key, required this.store});
  final ProductStore store;

  Future<void> _sendOrder(BuildContext context) async {
    if (store.cart.isEmpty) return;
    final lines = store.cart.entries.map((e) => '• ${e.key} — تعداد: ${e.value}').join('\n');
    final message = 'سلام، سفارش جدید از کاتالوگ ماهنشان پک:\n\n$lines\n\nلطفاً برای هماهنگی ثبت سفارش راهنمایی بفرمایید.';
    final uri = Uri.parse('https://wa.me/$whatsappNumber?text=${Uri.encodeComponent(message)}');
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('باز کردن واتساپ ممکن نشد. لطفاً واتساپ را نصب یا به‌روزرسانی کنید.')));
    }
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (context, _) => Scaffold(
      appBar: AppBar(title: const Text('سبد سفارش')),
      body: store.cart.isEmpty
        ? const Center(child: Text('سبد سفارش خالی است.'))
        : ListView(padding: const EdgeInsets.all(16), children: [
            const Text('فهرست سفارش شما', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            ...store.cart.entries.map((e) => Card(child: ListTile(
              title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('تعداد: ${e.value}'),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(onPressed: () => store.setCartCount(e.key, e.value - 1),
                  icon: const Icon(Icons.remove_circle_outline)),
                IconButton(onPressed: () => store.setCartCount(e.key, e.value + 1),
                  icon: const Icon(Icons.add_circle_outline)),
              ]),
            ))),
            const SizedBox(height: 12),
            const Text('قیمت‌ها در این نسخه نمایش داده نمی‌شوند.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF168C55),
                foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
              onPressed: () => _sendOrder(context),
              icon: const Icon(Icons.send_rounded),
              label: const Text('ثبت سفارش در واتساپ'),
            )),
          ]),
    ),
  );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key, required this.store});
  final ProductStore store;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (context, _) => Scaffold(
      appBar: AppBar(title: const Text('پنل مدیریت محصولات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context),
        icon: const Icon(Icons.add), label: const Text('افزودن محصول')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: store.products.length,
        itemBuilder: (context, i) {
          final p = store.products[i];
          return Card(child: ListTile(
            title: Text(p.name), subtitle: Text(p.category),
            trailing: PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') _edit(context, index: i, product: p);
                if (v == 'delete') store.remove(i);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ));
        },
      ),
    ),
  );

  Future<void> _edit(BuildContext context, {int? index, Product? product}) async {
    final name = TextEditingController(text: product?.name ?? '');
    final size = TextEditingController(text: product?.size ?? '');
    final desc = TextEditingController(text: product?.description ?? '');
    String category = product?.category ?? boxCategory;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: Text(product == null ? 'افزودن محصول' : 'ویرایش محصول'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام محصول')),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'دسته‌بندی'),
            items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) { if (v != null) setLocal(() => category = v); },
          ),
          TextField(controller: size, decoration: const InputDecoration(labelText: 'ابعاد / مشخصات')),
          TextField(controller: desc, maxLines: 3,
            decoration: const InputDecoration(labelText: 'توضیحات')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          FilledButton(onPressed: () async {
            if (name.text.trim().isEmpty) return;
            final p = Product(name: name.text.trim(), category: category,
              size: size.text.trim(), description: desc.text.trim());
            if (index == null) { await store.add(p); } else { await store.update(index, p); }
            if (ctx.mounted) Navigator.pop(ctx);
          }, child: const Text('ذخیره')),
        ],
      ),
    ));
    name.dispose(); size.dispose(); desc.dispose();
  }
}
