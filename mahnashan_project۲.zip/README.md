# Mahnashan Pack

Starter Flutter catalog app for Mahnashan Pack.

- Product catalog with categories for restaurants, drinks, and ice cream.
- Demo admin screen for adding, editing, and deleting products.
- Products are stored locally on the device.
- GitHub Actions workflow builds a release APK.

Demo admin PIN: `1234` (change before any public release).

Important: this starter does not yet include cloud synchronization, secure admin authentication, actual company product photography, or the official logo asset. Add the official logo and verified product details before publishing.
