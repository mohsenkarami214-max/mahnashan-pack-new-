import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const ink = Color(0xFF171411);
const gold = Color(0xFFD6AD62);
const productKey = 'mahnashan_products_v1';
const categories = ['همه محصولات', 'رستوران و فست‌فود', 'آبمیوه و نوشیدنی', 'بستنی و دسر'];

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = ProductStore();
  await store.load();
  runApp(MahnashanApp(store: store));
}

class Product {
  Product({required this.name, required this.category, this.size = '', this.description = ''});
  final String name, category, size, description;

  Map<String, dynamic> toJson() => {
    'name': name, 'category': category, 'size': size, 'description': description,
  };

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    name: json['name'] as String? ?? '',
    category: json['category'] as String? ?? categories[1],
    size: json['size'] as String? ?? '',
    description: json['description'] as String? ?? '',
  );
}

class ProductStore extends ChangeNotifier {
  final List<Product> products = [];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(productKey);
    if (raw != null) {
      try {
        products.addAll((jsonDecode(raw) as List).map(
          (e) => Product.fromJson(e as Map<String, dynamic>),
        ));
      } catch (_) {
        products.clear();
      }
    }
    if (products.isEmpty) {
      products.addAll([
        Product(name: 'ظرف بیرون‌بر', category: categories[1], size: 'ابعاد بر اساس سفارش'),
        Product(name: 'لیوان نوشیدنی', category: categories[2], size: 'ابعاد بر اساس سفارش'),
        Product(name: 'ظرف بستنی', category: categories[3], size: 'ابعاد بر اساس سفارش'),
      ]);
      await _save();
    }
  }

  Future<void> add(Product p) async { products.add(p); await _save(); notifyListeners(); }
  Future<void> update(int i, Product p) async { products[i] = p; await _save(); notifyListeners(); }
  Future<void> remove(int i) async { products.removeAt(i); await _save(); notifyListeners(); }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(productKey, jsonEncode(products.map((p) => p.toJson()).toList()));
  }
}

class MahnashanApp extends StatelessWidget {
  const MahnashanApp({super.key, required this.store});
  final ProductStore store;

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ماهنشان پک',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: gold),
      scaffoldBackgroundColor: const Color(0xFFF7F4EE),
      appBarTheme: const AppBarTheme(backgroundColor: ink, foregroundColor: Colors.white),
    ),
    home: HomePage(store: store),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.store});
  final ProductStore store;
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String filter = categories.first;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: widget.store,
    builder: (context, _) => Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.inventory_2_outlined, color: gold),
          SizedBox(width: 9),
          Text('ماهنشان پک', style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
        actions: [IconButton(
          tooltip: 'پنل مدیریت',
          onPressed: _adminLogin,
          icon: const Icon(Icons.admin_panel_settings_outlined),
        )],
      ),
      body: IndexedStack(index: tab, children: [_home(), _catalog(), _about()]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'محصولات'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'درباره ما'),
        ],
      ),
    ),
  );

  Widget _home() => ListView(padding: const EdgeInsets.all(16), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(colors: [ink, Color(0xFF383027)]),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Icon(Icons.inventory_2_rounded, color: gold, size: 76)),
        SizedBox(height: 12),
        Text('بسته‌بندی حرفه‌ای برای کسب‌وکار شما',
          style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
        SizedBox(height: 10),
        Text('کاتالوگ محصولات ماهنشان پک', style: TextStyle(color: gold, fontSize: 15)),
        SizedBox(height: 8),
        Text('چاپ و بسته‌بندی', style: TextStyle(color: Colors.white70)),
      ]),
    ),
    const SizedBox(height: 22),
    const Text('دسته‌بندی محصولات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    ...categories.skip(1).map((c) => Card(child: ListTile(
      leading: const Icon(Icons.category_outlined, color: gold),
      title: Text(c),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => setState(() { filter = c; tab = 1; }),
    ))),
    const SizedBox(height: 18),
    const Text('محصولات منتخب', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    ...widget.store.products.take(3).map((p) => ProductCard(product: p)),
  ]);

  Widget _catalog() {
    final list = widget.store.products.where((p) => filter == categories.first || p.category == filter).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('کاتالوگ محصولات', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        value: filter,
        decoration: const InputDecoration(labelText: 'دسته‌بندی', border: OutlineInputBorder()),
        items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
        onChanged: (v) => setState(() => filter = v ?? categories.first),
      ),
      const SizedBox(height: 12),
      if (list.isEmpty) const Center(child: Padding(
        padding: EdgeInsets.all(24), child: Text('محصولی در این دسته ثبت نشده است.'),
      )) else ...list.map((p) => ProductCard(product: p)),
    ]);
  }

  Widget _about() => ListView(padding: const EdgeInsets.all(20), children: const [
    Icon(Icons.business_rounded, size: 64, color: gold),
    SizedBox(height: 16),
    Text('ماهنشان پک', textAlign: TextAlign.center,
      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    SizedBox(height: 8),
    Text('چاپ و بسته‌بندی', textAlign: TextAlign.center),
    SizedBox(height: 16),
    Text('برای دریافت اطلاعات محصولات و ثبت سفارش، با مجموعه ماهنشان پک تماس بگیرید.',
      textAlign: TextAlign.center),
  ]);

  Future<void> _adminLogin() async {
    final pin = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ورود به پنل مدیریت'),
        content: TextField(
          controller: pin, obscureText: true, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'رمز مدیریت', hintText: 'رمز آزمایشی: 1234'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(ctx, pin.text == '1234'), child: const Text('ورود')),
        ],
      ),
    );
    pin.dispose();
    if (!mounted || ok != true) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPage(store: widget.store)));
  }
}

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product});
  final Product product;
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: ListTile(
      leading: const CircleAvatar(backgroundColor: ink,
        child: Icon(Icons.inventory_2_outlined, color: gold)),
      title: Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text([
        product.category,
        if (product.size.isNotEmpty) product.size,
        if (product.description.isNotEmpty) product.description,
      ].join(' • ')),
    ),
  );
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key, required this.store});
  final ProductStore store;

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (context, _) => Scaffold(
      appBar: AppBar(title: const Text('پنل مدیریت محصولات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context),
        icon: const Icon(Icons.add), label: const Text('افزودن محصول'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: store.products.length,
        itemBuilder: (context, i) {
          final p = store.products[i];
          return Card(child: ListTile(
            title: Text(p.name), subtitle: Text(p.category),
            trailing: PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'edit') _edit(context, index: i, product: p);
                if (v == 'delete') store.remove(i);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('ویرایش')),
                PopupMenuItem(value: 'delete', child: Text('حذف')),
              ],
            ),
          ));
        },
      ),
    ),
  );

  Future<void> _edit(BuildContext context, {int? index, Product? product}) async {
    final name = TextEditingController(text: product?.name ?? '');
    final size = TextEditingController(text: product?.size ?? '');
    final desc = TextEditingController(text: product?.description ?? '');
    String category = product?.category ?? categories[1];
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setLocal) => AlertDialog(
        title: Text(product == null ? 'افزودن محصول' : 'ویرایش محصول'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'نام محصول')),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(labelText: 'دسته‌بندی'),
            items: categories.skip(1).map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: (v) { if (v != null) setLocal(() => category = v); },
          ),
          TextField(controller: size, decoration: const InputDecoration(labelText: 'ابعاد / مشخصات')),
          TextField(controller: desc, maxLines: 3,
            decoration: const InputDecoration(labelText: 'توضیحات')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          FilledButton(onPressed: () async {
            if (name.text.trim().isEmpty) return;
            final p = Product(name: name.text.trim(), category: category,
              size: size.text.trim(), description: desc.text.trim());
            if (index == null) { await store.add(p); } else { await store.update(index, p); }
            if (ctx.mounted) Navigator.pop(ctx);
          }, child: const Text('ذخیره')),
        ],
      ),
    ));
    name.dispose(); size.dispose(); desc.dispose();
  }
}
